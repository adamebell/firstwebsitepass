1. Print out the following files:
	1x rules.pdf
	4x turns.pdf
	4x straights.pdf
	1x gear1.pdf
	2x gear2.pdf
	1x gear3.pdf
	2x gear4.pdf
	1x startfinish.pdf
2. Assign a color to A, B, C, and D and color in the cards from the gear files according to the lists in components.pdf to best match your cube equivalents (explanation of this is in rules.pdf)
3. Cut out the cards and map tiles
4. Have fun and email aemerson511@gmail.com with feedback or suggestions!

(ideally we would have better split up the gear cards, but game jams tend to cause you to run out of time)